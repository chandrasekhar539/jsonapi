<?php

namespace Drupal\jsonapi\Normalizer\ImpostorFrom\jsonapi_extras;

use Drupal\jsonapi_extras\Normalizer\ContentEntityDenormalizer;

/**
 * Impostor normalizer for ContentEntityDenormalizer.
 */
class ContentEntityDenormalizerImpostor extends ContentEntityDenormalizer {}
